Jeu d'�chec-----------
Url     : http://codes-sources.commentcamarche.net/source/52698-jeu-d-echecAuteur  : frankladen11Date    : 05/08/2013
Licence :
=========

Ce document intitul� � Jeu d'�chec � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour !!
<br />
<br />Je vous pr&eacute;sente un jeu d'&eacute;chec que j'ai
 r&eacute;alis&eacute; en JAVA, il s'agissait de mon projet synth&egrave;se de m
a session d'automne en programmation objet.
<br />
<br />J'aimerais savoir se 
que vous pensez de mon programme,
<br />
<br />Le code est bien comment&eacute
; et la doc est incluse,
<br />
<br />les commentaires sont appr&eacute;ci&eac
ute;s :)
<br />merci &agrave; tous !
