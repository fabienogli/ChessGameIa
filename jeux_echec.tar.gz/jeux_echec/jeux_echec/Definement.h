#ifndef DEFINEMENT_H
#define DEFINEMENT_H
enum piece { Pion,Rois, Reine,Fous,Tour,Cavalier,Rien};

#endif // DEFINEMENT_H
