Jeu d'echecs windows avec ia (+exe)-----------------------------------
Url     : http://codes-sources.commentcamarche.net/source/11088-jeu-d-echecs-windows-avec-ia-exeAuteur  : cs_NicolusDate    : 27/08/2013
Licence :
=========

Ce document intitul� � Jeu d'echecs windows avec ia (+exe) � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Jeu d'echec tournant sous Windows, avec IA (niveau de l'IA reglable dans le fich
ier game.c, voir MakeAutoMove())
<br />Bon pour le moment, seul l'alpha beta a 
&eacute;t&eacute; implement&eacute; (qui permet quand m&ecirc;me une profondeur 
permettant de battre la plupart des joueurs moyens!).
<br />la fonction d'evalu
ation du jeu est aussi assez nulle pour l'instant (tient seulement compte des po
ssessions materielles).
<br />ca avance bien tout de m&ecirc;me, le jeu est plu
t&ocirc;t agr&eacute;able. Essayez et dites moi!
<br /><a name='source-exemple'
></a><h2> Source / Exemple : </h2>
<br /><pre class='code' data-mode='basic'>

// Tout dans le zip (sources + exe)
</pre>
<br /><a name='conclusion'></a><h2
> Conclusion : </h2>
<br />Compilez avec VC++ 6 et il devrait pas y avoir de p
b.
